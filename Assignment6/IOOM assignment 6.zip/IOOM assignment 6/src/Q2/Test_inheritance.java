package Q2;
import java.lang.reflect.*;
import java.util.Scanner;
public class Test_inheritance extends Employee {

	public Test_inheritance(String fname, String lname, String ssn) {
		super(fname, lname, ssn);
	}
	@Override
	public double salary() {
		// TODO Auto-generated method stub
		
		return super.getSalary();
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("********************************");
		System.out.println("Employee Name: " + super.getFirstName() + " " + super.getLastName());
		System.out.println("Employee's Social Security Number: " + super.getSocialSecurityNumber());
		System.out.println("Salary: $ " + super.getSalary());
		System.out.println("********************************");
	}
	
	@SuppressWarnings("rawtypes")
	public static void main(String args[]) {
		Scanner sc = null;
		try {
			sc = new Scanner(System.in);
			System.out.println("Enter First Name");
			String fn = sc.next();
			System.out.println("Enter Last Name");
			String ln = sc.next();
			System.out.println("Enter Social Security Number");
			String ssn = sc.next();
			System.out.println("Enter Salary (USD)");
			double sal = sc.nextDouble();
			
			Test_inheritance obj = new Test_inheritance(fn, ln, ssn);
			obj.setSalary(sal);
			Class<?> cls = obj.getClass();
			System.out.println("Superclass of " + cls + " is " + cls.getSuperclass());
			
			System.out.println("Fields in " + cls.getSuperclass() + " are: ");
			for(Field f: cls.getFields()) {
				System.out.print(f + ", ");
			}
			System.out.println("Constructors in " + cls.getSuperclass() + " are: ");
			for(Constructor c: cls.getConstructors()) {
				System.out.print(c.getName() + ": Parameter Types: \n");
				for(Class p: c.getParameterTypes()) {
					System.out.println("\t" + p);
				}
			}
			System.out.println("\nMethods in superclass of Test_inheritance which is '" + cls.getSuperclass() + "' are: ");
			for(Method m: cls.getMethods()) {
				System.out.println(m.getName() + ": Parameter Types:");
				Class<?>[] temp = m.getParameterTypes();
				if(temp.length == 0) {
					System.out.println("\tNo parameters!");
				}else {
					for(Class p: temp) {
						System.out.println("\t" + p);
					}
				}				
			}
			System.out.println();
			System.out.println("Invoking a method '" + cls.getMethod("print") + "' using reflection:");
			cls.getMethod("print").invoke((Object)obj);
			
		} catch(IllegalArgumentException e) {
			System.out.println("Illegal Argument Exception");
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			System.out.println("Illegal Access Exception");
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			System.out.println("Invocation Target Exception");
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			System.out.println("No such method Exception");
			e.printStackTrace();
		} catch (SecurityException e) {
			System.out.println("Security Exception");
			e.printStackTrace();
		}finally {
			sc.close();
		}
	}
}
