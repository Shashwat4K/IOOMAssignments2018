package Q2;
abstract class Employee {
	
	private	String FirstName;
	private	String LastName;
	private	String SocialSecurityNumber;
	private double Salary = 0.0; 
	public Employee(String fname, String lname, String ssn) {
		FirstName = fname;
		LastName = lname;
		SocialSecurityNumber = ssn;
	}
	public void setFirstName(String fname) {
		FirstName= fname; 
	}
	public void setLastName(String lname) {
		LastName= lname; 
	}	
	public void setSocialSecurityNumber(String SSN) {
		SocialSecurityNumber = SSN;
	}
	public String getFirstName() {
		return FirstName;
	}
	public String getLastName() {
		return LastName;
	}
	public String getSocialSecurityNumber() {
		return SocialSecurityNumber;
	}
	public void setSalary(double s) {
		Salary = s;
	}
	public double getSalary() {
		return Salary;
	}
	abstract public double salary();
	abstract public void print();
}
