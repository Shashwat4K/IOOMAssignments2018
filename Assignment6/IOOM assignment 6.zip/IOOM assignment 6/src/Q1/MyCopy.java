package Q1;
import java.io.*;
public class MyCopy {
	private BufferedReader input = null;
	private PrintWriter printer = null;
	public void closeResources() {
		if(printer != null)
		{
			printer.close();
		}
		if(input!=null) {
			try {
				//System.out.println("\"input\" closed");
				input.close();
			} catch (IOException e) {
				System.out.println("Failed to close input");
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		MyCopy obj = null;
		try {
			obj = new MyCopy();
			obj.input = new BufferedReader(new FileReader(args[0]));
			obj.printer = new PrintWriter(new File(args[1]).getAbsoluteFile());
			String s;
			while((s = obj.input.readLine())!=null) {
				obj.printer.write(s + "\n");
			}
			
		}catch(FileNotFoundException e) {
			System.out.println("File "+args[0]+" NOT Found!");
		}catch(IOException e) {
			System.out.println("IOException occured! Check the 'writer' part!");
		}finally {
			obj.closeResources();
		}
	}
}
